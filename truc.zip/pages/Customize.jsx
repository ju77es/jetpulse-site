export default function Customize() {
  return (
    <div className="text-center p-10">
      <h1 className="text-4xl font-bold">Personnalisation</h1>
      <p className="mt-4 text-lg">Téléchargez une image et personnalisez votre gravure.</p>
      <input type="file" className="mt-6 block mx-auto bg-gray-700 p-2 rounded-lg" />
    </div>
  );
}