export default function Home() {
  return (
    <div className="text-center p-10">
      <h1 className="text-4xl font-bold">Bienvenue sur JetPulse</h1>
      <p className="mt-4 text-lg">Personnalisation de gravure laser en ligne.</p>
    </div>
  );
}